using KayitGiris.Models;
using Microsoft.AspNetCore.Mvc;



namespace KayitGiris.Controllers
{
    public class CourseController : Controller
    {
        public IActionResult Index(){

         var model= Repository.Applications;
           return View();
        }
        public IActionResult Apply(){
           
           return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Apply([FromForm] Candidate model){
           
           Repository.Add(model);
           return View("Feedback",model);
        }

    }
}